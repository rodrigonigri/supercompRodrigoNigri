# Projeto da Maratona de Filmes:
## Feito por: Rodrigo Nigri Griner
## (Para visualizar o arquivo em Markdown, pressione Ctrl+Shift+V no Vscode)

# Problema:
Você quer passar um final de semana assistindo ao máximo de filmes possível, mas há restrições quanto aos horários disponíveis e ao número de títulos que podem ser vistos em cada categoria (comédia, drama, ação, etc).

Entrada: Um inteiro N representando o número de filmes disponíveis para assistir e N trios de inteiros `(H[i], F[i], C[i])`, representando a hora de início, a hora de fim e a categoria do i-ésimo filme. Além disso, um inteiro M representando o número de categorias e uma lista de M inteiros representando o número máximo de filmes que podem ser assistidos em cada categoria.

Saída: Um inteiro representando o número máximo de filmes que podem ser assistidos de acordo com as restrições de horários e número máximo por categoria.

# Objetivo:
O objetivo do projeto é criar diversos programas fazendo o uso de diferentes heurísticas, para retornar o número máximo de filmes que podem ser assistidos de acordo com as restrições de horários e número máximo por categoria.

# Problema Discreto vs Problema Contínuo:
Se o nosso problema fosse contínuo, seria mais fácil de resolver, pois utilizando cálculo e derivadas, poderíamos encontrar o valor máximo da função objetivo. Porém, como o nosso problema é discreto, não sabemos os vizinhos de um ponto, e por isso, não é possível derivar a função para encontrar o valor máximo. Por isso, utilizaremos heurísticas para tentar encontrar esse valor máximo.

<img src="discretoContinuo.png" alt="Alt text" title="Discreto vs Contínuo" width=500rem/>

# Implementação das Heurísticas:
## Heurística Gulosa:

### Pseudocódigo:
```
1. Organizar os filmes em um vetor de filmes (struct Filme: HoraInicio, HoraFim, Categoria)
2. Organizar as categorias em um vetor de categorias
3. Organizar os filmes em ordem crescente de HoraFim
4. Inicializar um vetor cronograma de filmes assistidos
5. Inicializar um vetor de categorias assistidas
6. Inicializar um inteiro com o número de filmes assistidos
7. Para cada filme do vetor de filmes:
    verifica se o filme está dentro do horário e se a categoria ainda não ultrapassou o limite
    adiciona o filme no vetor cronograma de filmes assistidos
    acrescenta a categoria no vetor de categorias assistidas
    incrementa o número de filmes assistidos
    atualiza o horário
8. Retorna o número de filmes assistidos
```	

### Código Comentado:

``` c++

// importando bibliotecas
#include<iostream>
#include<vector>
#include<algorithm>
#include <random>
#include <stdlib.h>
#include <fstream>

#define RESET   "\033[0m"
#define BLACK   "\033[30m"      /* Black */
#define RED     "\033[31m"      /* Red */
#define GREEN   "\033[32m"      /* Green */
#define YELLOW  "\033[33m"      /* Yellow */
#define BLUE    "\033[34m"      /* Blue */
#define MAGENTA "\033[35m"      /* Magenta */
#define CYAN    "\033[36m"      /* Cyan */
#define WHITE   "\033[37m"      /* White */
#define BOLDBLACK   "\033[1m\033[30m"      /* Bold Black */
#define BOLDRED     "\033[1m\033[31m"      /* Bold Red */
#define BOLDGREEN   "\033[1m\033[32m"      /* Bold Green */
#define BOLDYELLOW  "\033[1m\033[33m"      /* Bold Yellow */
#define BOLDBLUE    "\033[1m\033[34m"      /* Bold Blue */
#define BOLDMAGENTA "\033[1m\033[35m"      /* Bold Magenta */
#define BOLDCYAN    "\033[1m\033[36m"      /* Bold Cyan */
#define BOLDWHITE   "\033[1m\033[37m"      /* Bold White */

using namespace std;

struct filme {
    int id;
    int inicio;
    int fim;
    int categoria;
};

// função de comparação para ordenar os filmes pelo fim
bool my_compare(filme a, filme b){
    return a.fim < b.fim; // ordenando pelo mais leve
}

// função que cria o arquivo de saída
void createOutput(int numero_filmes, int tempo_de_tela){
    ofstream output;
    output.open("output_gulosa.txt", std::ios_base::app);
    output << numero_filmes << " " << tempo_de_tela << " " << (double)tempo_de_tela/numero_filmes << endl;
    output.close();
}

int main(){
    int numero_filmes;
    int numero_categorias;
    vector<filme> filmes; // vetor que armazena todos os filmes
    vector<filme> cronograma; // vetor que armazena os filmes que serao vistos no dia
    vector<int> maximo_categorias; // vetor que diz quantos filmes por categoria {'0',3,7,5,2}


    cin >> numero_filmes >> numero_categorias;

    // lendo as categorias
    maximo_categorias.push_back(0);

    int max;
    for(int i = 0; i < numero_categorias; i++){
        cin >> max;
        maximo_categorias.push_back(max);

    }

    // lendo os filmes
    int hora_inicio, hora_fim, cat;
    for(int i = 0; i < numero_filmes; i++){
        cin >> hora_inicio;
        cin >> hora_fim;
        cin >> cat;

        if(hora_fim == 0){
            hora_fim = 24;
        }

        if(hora_fim > hora_inicio){
            filmes.push_back({i, hora_inicio,hora_fim, cat});
        }
        

    }

    // ordenando os filmes pelo fim
    sort(filmes.begin(), filmes.end(), my_compare);

    int hora_atual = 0;
    for(auto& this_film : filmes){
        
        // se o filme estiver dentro do horario e a categoria ainda nao tiver sido assistida o filme entra no cronograma
        if(hora_atual <= this_film.inicio && maximo_categorias[this_film.categoria] > 0){
            cronograma.push_back(this_film);
            hora_atual = this_film.fim;
            maximo_categorias[this_film.categoria] -= 1;

        }

    }

    // criando o arquivo de saida
    int numero_filmes_vistos = 0;
    int tempo_de_tela = 0;
    for(auto& this_film:cronograma){
        numero_filmes_vistos += 1;
        tempo_de_tela += this_film.fim - this_film.inicio;
    }
    createOutput(numero_filmes_vistos, tempo_de_tela);


    return 0;
}
```
### Valgrind:
```
--------------------------------------------------------------------------------
-- User-annotated source: gulosa.cpp
--------------------------------------------------------------------------------
Ir     

-- line 27 ----------------------------------------
     .  
     .  struct filme {
     .      int id;
     .      int inicio;
     .      int fim;
     .      int categoria;
     .  };
     .  
 8,070  bool my_compare(filme a, filme b){
16,200      return a.fim < b.fim; // ordenando pelo mais leve
 8,070  }
     .  
    13  void createOutput(int numero_filmes, int tempo_de_tela){
     .      ofstream output;
     .      output.open("output_gulosa.txt", std::ios_base::app);
    13      output << numero_filmes << " " << tempo_de_tela << " " << (double)tempo_de_tela/numero_filmes << endl;
 8,346  => ???:0x000000000010a3f0 (2x)
     .      output.close();
    11  }
     .  
    11  int main(){
     .      int numero_filmes;
     .      int numero_categorias;
     .      vector<filme> filmes; // vetor que armazena todos os filmes
     .      vector<filme> cronograma; // vetor que armazena os filmes que serao vistos no dia
     .      vector<int> maximo_categorias; // vetor que diz quantos filmes por categoria {'0',3,7,5,2}
     .  
     .  
     6      cin >> numero_filmes >> numero_categorias;
 8,358  => ???:0x000000000010a2a0 (2x)
     .  
     .      
     1      maximo_categorias.push_back(0);
     .  
     .      int max;
    34      for(int i = 0; i < numero_categorias; i++){
    24          cin >> max;
 7,984  => ???:0x000000000010a2a0 (8x)
     .          maximo_categorias.push_back(max);
     .  
     .      }
     .  
     .      int hora_inicio, hora_fim, cat;
 6,625      for(int i = 0; i < numero_filmes; i++){
 3,000          cin >> hora_inicio;
1,131,291  => ???:0x000000000010a2a0 (1,000x)
 3,001          cin >> hora_fim;
1,132,351  => ???:0x000000000010a2a0 (1,000x)
 3,000          cin >> cat;
998,000  => ???:0x000000000010a2a0 (1,000x)
     .  
 3,000          if(hora_fim == 0){
    70              hora_fim = 24;
     .          }
     .  
 3,000          if(hora_fim > hora_inicio){
 4,580              filmes.push_back({i, hora_inicio,hora_fim, cat});
     .          }
     .          
     .  
     .      }
     .  
     .      sort(filmes.begin(), filmes.end(), my_compare);
     .  
     1      int hora_atual = 0;
 2,729      for(auto& this_film : filmes){
     .  
 2,886          if(hora_atual <= this_film.inicio && maximo_categorias[this_film.categoria] > 0){
     .              cronograma.push_back(this_film);
    22              hora_atual = this_film.fim;
    44              maximo_categorias[this_film.categoria] -= 1;
     .  
     .          }
     .  
     .      }
     .  
     .      int numero_filmes_vistos = 0;
     .      int tempo_de_tela = 0;
    41      for(auto& this_film:cronograma){
     .          numero_filmes_vistos += 1;
    79          tempo_de_tela += this_film.fim - this_film.inicio;
     .      }
     .  
     1      createOutput(numero_filmes_vistos, tempo_de_tela);
38,398  => gulosa.cpp:createOutput(int, int) (1x)
     .  
     .      cout<<"\n\n\n";
     .      
     .      cout << "|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|" << endl;
     .      cout << "|00\t01\t02\t03\t04\t05\t06\t07\t08\t09\t10\t11\t12\t13\t14\t15\t16\t17\t18\t19\t20\t21\t22\t23\t|" << endl;
     .      int agora = 0;
     .      int numero_de_espacos = 0;
     .      int numero_de_filme = 0;
    47      for(auto& this_film : cronograma){
    22          agora = this_film.inicio;
     .          numero_de_espacos = agora;
    44          numero_de_filme = this_film.fim - this_film.inicio;
   807          for(int i = 0; i<numero_de_espacos; i++){
     .              cout<<"\t";
     .          }
     .  
   138          for(int i = 0; i<numero_de_filme; i++){
    72              if(this_film.categoria==1){
     .                  cout << RED;
     .              }
    46              else if (this_film.categoria==2){
     .                  cout << GREEN;
     .              }
    36              else if (this_film.categoria==3){
     .                  cout << MAGENTA;
     .              }
    26              else if (this_film.categoria==4){
     .                  cout << YELLOW;
     .              }
    18              else if (this_film.categoria==5){
     .                  cout << BLUE;
     .              }
    12              else if (this_film.categoria==6){
     .                  cout << MAGENTA;
     .              }
    10              else if (this_film.categoria==7){
     .                  cout << CYAN;
     .              }
     .              
     .              cout<<"|"<<"|"<<"|"<<"|"<<"|"<<"|"<<"|"<<"|";
     .              cout << RESET;
     .          }
     .          cout<<endl;
     .          
     .      }
     .      cout << "|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|" << endl;
     .  
     .  
     .  
     .  
     .      return 0;
    15  }
     .  
     .  

--------------------------------------------------------------------------------
Ir     
--------------------------------------------------------------------------------
65,825  events annotated
```

Observando-se a saída do Valgrind percebe-se que o programa gasta 65,825 eventos anotados, sendo que 38,398 deles são referentes à função createOutput(int, int) e 27,427 são referentes à função main(). 


## Heurística Gulosa Randomizada:

### Pseudocódigo:
``` 
1. Organizar os filmes em um vetor de filmes (struct Filme: HoraInicio, HoraFim, Categoria)
2. Organizar as categorias em um vetor de categorias
3. Organizar os filmes em ordem crescente de HoraFim
4. Inicializar um vetor cronograma de filmes assistidos
5. Inicializar um vetor organizador de horários
6. Inicializar um vetor de categorias assistidas
7. Inicializar um inteiro com o número de filmes assistidos
8. Para cada filme do vetor de filmes:
    verifica se o organizador de horários está disponível
        adiciona o filme no vetor cronograma de filmes assistidos
        acrescenta a categoria no vetor de categorias assistidas
        incrementa o número de filmes assistidos
        altera o organizador de horários
        atualiza o horário
9. Randomiza um número de 0 a 1
10. Se o número for maior que 0.75:
    verifica se o organizador de horários está disponível
        randomiza um número de 0 a [tamanho do vetor de filmes restantes]
        remove o filme do vetor de filmes restantes
        adiciona o filme no vetor cronograma de filmes assistidos
        altera o organizador de horários
11. Retorna o número de filmes assistidos
```

### Código Comentado:

```c++
// importando bibliotecas necessárias
#include<iostream>
#include<vector>
#include<algorithm>
#include <random>
#include <stdlib.h>
#include <fstream>


// definindo cores para o terminal
#define RESET   "\033[0m"
#define BLACK   "\033[30m"      /* Black */
#define RED     "\033[31m"      /* Red */
#define GREEN   "\033[32m"      /* Green */
#define YELLOW  "\033[33m"      /* Yellow */
#define BLUE    "\033[34m"      /* Blue */
#define MAGENTA "\033[35m"      /* Magenta */
#define CYAN    "\033[36m"      /* Cyan */
#define WHITE   "\033[37m"      /* White */
#define BOLDBLACK   "\033[1m\033[30m"      /* Bold Black */
#define BOLDRED     "\033[1m\033[31m"      /* Bold Red */
#define BOLDGREEN   "\033[1m\033[32m"      /* Bold Green */
#define BOLDYELLOW  "\033[1m\033[33m"      /* Bold Yellow */
#define BOLDBLUE    "\033[1m\033[34m"      /* Bold Blue */
#define BOLDMAGENTA "\033[1m\033[35m"      /* Bold Magenta */
#define BOLDCYAN    "\033[1m\033[36m"      /* Bold Cyan */
#define BOLDWHITE   "\033[1m\033[37m"      /* Bold White */

using namespace std;

struct filme {
    int id;
    int inicio;
    int fim;
    int categoria;
};

// função que verifica se o filme está dentro do horário
bool verifica_calendario(filme f, vector<int> v){
    for(int i = f.inicio; i < f.fim; i++){
        if(v.at(i) == 1){
            return false;
        }
    }
    return true;
}

// função que altera o vetor de horários
void altera_calendario(filme f, vector<int>& v){
    for(int i = f.inicio; i < f.fim; i++){
        v[i] = true;
    }
}

// função que vai ser usada no sort para ordenar os filmes por fim
bool my_compare(filme a, filme b){
    return a.fim < b.fim; // ordenando pelo mais leve
}

// função que escreve no output (.txt)
void createOutput(int numero_filmes, int tempo_de_tela){
    ofstream output;
    output.open("output_aleatoria.txt", std::ios_base::app);
    output << numero_filmes << " " << tempo_de_tela << " " << (double)tempo_de_tela/numero_filmes << endl;
    output.close();
}

int main(){
    int numero_filmes;
    int numero_categorias;
    vector<filme> filmes; // vetor que armazena todos os filmes
    vector<filme> cronograma; // vetor que armazena os filmes que serao vistos no dia
    vector<int> maximo_categorias; // vetor que diz quantos filmes por categoria {'0',3,7,5,2}
    vector<int> organizador_de_horarios;
    int eliminados = 0; // filmes que o gerador de input gerou que nao se encaixam nas regras do problema.

    // CRIANDO VETOR DE 24 POSICOES TODAS FALSE PARA SABER QUAIS HORARIOS JA FORAM OS FILMES.
    for(int i = 0; i < 24; i++){
        organizador_de_horarios.push_back(false);
    }

    cin >> numero_filmes >> numero_categorias;

    maximo_categorias.push_back(0); // so pra ficar alinhado (cat1 na posicao 1, cat2 na posicao 2...)

    
    // CRIANDO O VETOR QUE INDICA QUANTOS FILMES PODE VER POR CATEGORIA
    int max;
    for(int i = 0; i < numero_categorias; i++){
        cin >> max;
        maximo_categorias.push_back(max);

    }

    // CRIANDO O VETOR CONTENDO TODOS OS FILMES, JA DESCARTNDO OS DEPOIS DAS 00:00
    int hora_inicio, hora_fim, cat;
    for(int i = 0; i < numero_filmes; i++){
        cin >> hora_inicio;
        cin >> hora_fim;
        cin >> cat;

        // meia noite é representada como 0, mas no vetor de horarios é 24
        if(hora_fim == 0){
            hora_fim = 24;
        }

        // se o filme terminar depois das 00:00, ele nao entra no vetor de filmes
        if(hora_fim > hora_inicio){
            filmes.push_back({i, hora_inicio,hora_fim, cat});
            eliminados = eliminados + 1;
        }

    }

    numero_filmes = numero_filmes - eliminados;

    // ordenando os filmes por fim
    sort(filmes.begin(), filmes.end(), my_compare);
    //unsigned seed = chrono::system_clock::now().time_since_epoch().count();
    default_random_engine generator(10); // random com a seed 10

    int i = 1;
    for(auto& this_film : filmes){
        uniform_real_distribution<double> distribution(0.0, 1.0);

        // se o filme nao estiver no horario e ainda tiver dessa categoria, ele entra no cronograma
        if(verifica_calendario(this_film, organizador_de_horarios) && maximo_categorias[this_film.categoria] > 0){
            cronograma.push_back(this_film);
            altera_calendario(this_film, organizador_de_horarios);
            maximo_categorias[this_film.categoria] -= 1;
        }

        // parte da aleatoriedade:
        // se o numero aleatorio for maior que 0.75 e o filme nao estiver no horario e ainda tiver dessa categoria, ele entra no cronograma
        if (distribution(generator) > 0.75 && i < numero_filmes){
            uniform_int_distribution<int> distribution(i, numero_filmes - 1);
            int p = distribution(generator);

            if(verifica_calendario(filmes[p], organizador_de_horarios) && maximo_categorias[this_film.categoria] > 0){
                cronograma.push_back(filmes[p]);
                altera_calendario(filmes[p], organizador_de_horarios);
                maximo_categorias[filmes[p].categoria] -= 1;
                filmes.erase(filmes.begin()+p-1);
                numero_filmes = numero_filmes - 1;
            }
        }

        i += 1;

    }

    // criando o output
    int numero_filmes_vistos = 0;
    int tempo_de_tela = 0;
    for(auto& this_film:cronograma){
        numero_filmes_vistos += 1;
        tempo_de_tela += this_film.fim - this_film.inicio;
    }

    createOutput(numero_filmes_vistos, tempo_de_tela);
    return 0;
}
```

### Valgrind:
```
--------------------------------------------------------------------------------
-- User-annotated source: aleatoria.cpp
--------------------------------------------------------------------------------
Ir     

-- line 28 ----------------------------------------
     .  struct filme {
     .      int id;
     .      int inicio;
     .      int fim;
     .      int categoria;
     .  };
     .  
     .  
    18  bool verifica_calendario(filme f, vector<int> v){
 1,999      for(int i = f.inicio; i < f.fim; i++){
 2,887          if(v.at(i) == 1){
    17              return false;
     .          }
     .      }
     2      return true;
    17  }
     .  
     .  void altera_calendario(filme f, vector<int>& v){
   126      for(int i = f.inicio; i < f.fim; i++){
   143          v[i] = true;
     .      }
     .  }
     .  
     .  
 8,070  bool my_compare(filme a, filme b){
16,200      return a.fim < b.fim; // ordenando pelo mais leve
 8,070  }
     .  
    13  void createOutput(int numero_filmes, int tempo_de_tela){
     .      ofstream output;
     .      output.open("output_aleatoria.txt", std::ios_base::app);
    13      output << numero_filmes << " " << tempo_de_tela << " " << (double)tempo_de_tela/numero_filmes << endl;
 8,346  => ???:0x000000000010a430 (2x)
     .      output.close();
    11  }
     .  
    11  int main(){
     .      int numero_filmes;
     .      int numero_categorias;
     .      vector<filme> filmes; // vetor que armazena todos os filmes
     .      vector<filme> cronograma; // vetor que armazena os filmes que serao vistos no dia
     .      vector<int> maximo_categorias; // vetor que diz quantos filmes por categoria {'0',3,7,5,2}
     .      vector<int> organizador_de_horarios;
     2      int eliminados = 0; // filmes que o gerador de input gerou que nao se encaixam nas regras do problema.
     .  
     .      // CRIANDO VETOR DE 24 POSICOES TODAS FALSE PARA SABER QUAIS HORARIOS JA FORAM OS FILMES.
    94      for(int i = 0; i < 24; i++){
    24          organizador_de_horarios.push_back(false);
     .      }
     .  
     6      cin >> numero_filmes >> numero_categorias;
 8,358  => ???:0x000000000010a2d0 (2x)
     .  
     .      
     1      maximo_categorias.push_back(0); // so pra ficar alinhado (cat1 na posicao 1, cat2 na posicao 2...)
     .  
     .      
     .      // CRIANDO O VETOR QUE INDICA QUANTOS FILMES PODE VER POR CATEGORIA
     .      int max;
    34      for(int i = 0; i < numero_categorias; i++){
    24          cin >> max;
 7,984  => ???:0x000000000010a2d0 (8x)
     .          maximo_categorias.push_back(max);
     .  
     .      }
     .  
     .      // CRIANDO O VETOR CONTENDO TODOS OS FILMES, JA DESCARTNDO OS DEPOIS DAS 00:00
     .      int hora_inicio, hora_fim, cat;
 4,005      for(int i = 0; i < numero_filmes; i++){
 3,000          cin >> hora_inicio;
1,131,291  => ???:0x000000000010a2d0 (1,000x)
 3,001          cin >> hora_fim;
1,132,351  => ???:0x000000000010a2d0 (1,000x)
 3,000          cin >> cat;
998,000  => ???:0x000000000010a2d0 (1,000x)
     .  
 3,000          if(hora_fim == 0){
    70              hora_fim = 24;
     .          }
     .  
 3,000          if(hora_fim > hora_inicio){
 4,580              filmes.push_back({i, hora_inicio,hora_fim, cat});
   916              eliminados = eliminados + 1;
     .          }
     .  
     .      }
     .  
     2      numero_filmes = numero_filmes - eliminados;
     .  
     .      sort(filmes.begin(), filmes.end(), my_compare);
     .      //unsigned seed = chrono::system_clock::now().time_since_epoch().count();
     .      default_random_engine generator(10); // random com a seed 10
     .  
     1      int i = 1;
 1,835      for(auto& this_film : filmes){
     .          uniform_real_distribution<double> distribution(0.0, 1.0);
     .  
     .  
    95          if(verifica_calendario(this_film, organizador_de_horarios) && maximo_categorias[this_film.categoria] > 0){
    57              cronograma.push_back(this_film);
 1,244  => /usr/include/c++/9/bits/stl_vector.h:std::vector<filme, std::allocator<filme> >::push_back(filme const&) (19x)
    38              altera_calendario(this_film, organizador_de_horarios);
    57              maximo_categorias[this_film.categoria] -= 1;
     .          }
     .  
 2,489          if (distribution(generator) > 0.75 && i < numero_filmes){
    36              uniform_int_distribution<int> distribution(i, numero_filmes - 1);
     .              int p = distribution(generator);
     .  
   166              if(verifica_calendario(filmes[p], organizador_de_horarios) && maximo_categorias[this_film.categoria] > 0){
   323  => aleatoria.cpp:verifica_calendario(filme, std::vector<int, std::allocator<int> >) (18x)
     2                  cronograma.push_back(filmes[p]);
   236  => /usr/include/c++/9/bits/stl_vector.h:std::vector<filme, std::allocator<filme> >::push_back(filme const&) (1x)
     .                  altera_calendario(filmes[p], organizador_de_horarios);
     2                  maximo_categorias[filmes[p].categoria] -= 1;
     .                  filmes.erase(filmes.begin()+p-1);
     2                  numero_filmes = numero_filmes - 1;
     .              }
     .          }
     .  
 1,832          i += 1;
     .  
     .      }
     .  
     1      int numero_filmes_vistos = 0;
     1      int tempo_de_tela = 0;
    40      for(auto& this_film:cronograma){
     .          numero_filmes_vistos += 1;
    72          tempo_de_tela += this_film.fim - this_film.inicio;
     .      }
     .  
     1      createOutput(numero_filmes_vistos, tempo_de_tela);
38,017  => aleatoria.cpp:createOutput(int, int) (1x)
     .  
     .      
     .  
     .      cout<<"\n\n\n";
     .      
     .      cout << "|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|" << endl;
     .      cout << "|00\t01\t02\t03\t04\t05\t06\t07\t08\t09\t10\t11\t12\t13\t14\t15\t16\t17\t18\t19\t20\t21\t22\t23\t|" << endl;
     .      int agora = 0;
     .      int numero_de_espacos = 0;
     .      int numero_de_filme = 0;
    43      for(auto& this_film : cronograma){
    20          agora = this_film.inicio;
     .          numero_de_espacos = agora;
    40          numero_de_filme = this_film.fim - this_film.inicio;
   787          for(int i = 0; i<numero_de_espacos; i++){
     .              cout<<"\t";
     .          }
     .  
   129          for(int i = 0; i<numero_de_filme; i++){
    69              if(this_film.categoria==1){
     .                  cout << RED;
     .              }
    44              else if (this_film.categoria==2){
     .                  cout << GREEN;
     .              }
    34              else if (this_film.categoria==3){
     .                  cout << MAGENTA;
     .              }
    24              else if (this_film.categoria==4){
     .                  cout << YELLOW;
     .              }
    16              else if (this_film.categoria==5){
     .                  cout << BLUE;
     .              }
    16              else if (this_film.categoria==6){
     .                  cout << MAGENTA;
     .              }
    14              else if (this_film.categoria==7){
     .                  cout << CYAN;
     .              }
     .              else{
     .                  cout << RESET;
     .              }
     .              
     .              cout<<"|"<<"|"<<"|"<<"|"<<"|"<<"|"<<"|"<<"|";
     .              cout << RESET;
-- line 196 ----------------------------------------
-- line 199 ----------------------------------------
     .          
     .      }
     .      cout << "|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|" << endl;
     .  
     .  
     .  
     .  
     .      return 0;
    15  }
     .  
     .  

--------------------------------------------------------------------------------
Ir     
--------------------------------------------------------------------------------
70,334  events annotated
```

Observando-se a saída do Valgrind percebe-se que o programa gasta 70,334 eventos anotados, sendo que 38,017 deles são referentes a função createOutput. Isso significa que a função createOutput é a que mais consome tempo de execução do programa. 

## Output visual dos programas (usado somente para verificar se nenhum filme se sobrepõe ou se alguma categoria foi excedida):
### Codigo:
``` c++
cout<<"\n\n\n";
    
    cout << "|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|" << endl;
    cout << "|00\t01\t02\t03\t04\t05\t06\t07\t08\t09\t10\t11\t12\t13\t14\t15\t16\t17\t18\t19\t20\t21\t22\t23\t|" << endl;
    int agora = 0;
    int numero_de_espacos = 0;
    int numero_de_filme = 0;
    for(auto& this_film : cronograma){
        agora = this_film.inicio;
        numero_de_espacos = agora;
        numero_de_filme = this_film.fim - this_film.inicio;
        for(int i = 0; i<numero_de_espacos; i++){
            cout<<"\t";
        }

        for(int i = 0; i<numero_de_filme; i++){
            if(this_film.categoria==1){
                cout << RED;
            }
            else if (this_film.categoria==2){
                cout << GREEN;
            }
            else if (this_film.categoria==3){
                cout << MAGENTA;
            }
            else if (this_film.categoria==4){
                cout << YELLOW;
            }
            else if (this_film.categoria==5){
                cout << BLUE;
            }
            else if (this_film.categoria==6){
                cout << MAGENTA;
            }
            else if (this_film.categoria==7){
                cout << CYAN;
            }
            else{
                cout << RESET;
            }
            
            cout<<"|"<<"|"<<"|"<<"|"<<"|"<<"|"<<"|"<<"|";
            cout << RESET;
        }
        cout<<endl;
        
    }
    cout << "|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|" << endl;
```
### Gulosa:
<img src="gulosa.jpeg" alt="Alt text" title="Discreto vs Contínuo" width=1000rem/>

### Aleatória:
<img src="aleatoria.jpeg" alt="Alt text" title="Discreto vs Contínuo" width=1000rem/>

# Resultados:

## Tempo de execução:
Tendências foram observadas ao analisar o tempo de execução das diferentes heurísticas e quantidades de filmes em um arquivo de entrada. A primeira tendência é esperada, pois quanto maior o número de filmes no arquivo, maior será o tempo de execução. A segunda tendência é menos evidente, já que as duas heurísticas apresentam tempos de execução bastante semelhantes.
Observe os gráficos abaixo:

<img src="graficos\tempo x numero de filmes gulosa.png" alt="Alt text" title="Discreto vs Contínuo" width=500rem/>
<img src="graficos\tempo x numero de filmes aleatoria.png" alt="Alt text" title="Discreto vs Contínuo" width=500rem/>
<img src="graficos\tempo x numero de filmes geral.png" alt="Alt text" title="Discreto vs Contínuo" width=500rem/>
<img src="graficos\tempo x numero categorias gulosa.png" alt="Alt text" title="Discreto vs Contínuo" width=500rem/>
<img src="graficos\tempo x numero categorias aleatoria.png" alt="Alt text" title="Discreto vs Contínuo" width=500rem/>
<img src="graficos\tempo x numero categorias geral.png" alt="Alt text" title="Discreto vs Contínuo" width=500rem/>

Ao explorarmos o impacto dos dados de entrada no tempo de execução, incluímos a métrica de número de categorias nas análises acima. Observamos como o tempo varia em um gráfico 3D para ambas as heurísticas. Notamos que o número de categorias não parece ter um grande impacto sobre o tempo de execução, mas fica ainda mais evidente a tendência de aumento do tempo conforme aumenta o número de filmes:

<img src="graficos\tempo x numero categorias x numero de filmes gulosa.png" alt="Alt text" title="Discreto vs Contínuo" width=500rem/>
<img src="graficos\tempo x numero categorias x numero de filmes aleatoria.png" alt="Alt text" title="Discreto vs Contínuo" width=500rem/>



## Filmes assistidos:
A métrica que o algoritmo deve maximizar é o número total de filmes assistidos, e o resultado de qual modelo obteve o melhor desempenho nessa métrica é crucial para as conclusões do projeto. Contudo, é importante notar que o número de filmes assistidos pode ser influenciado pelo número de categorias, tornando o gráfico pouco conclusivo ao considerar ambas as heurísticas e todas as categorias:

<img src="graficos\filmes entrada x filmes assistidos gulosa.png" alt="Alt text" title="Discreto vs Contínuo" width=500rem/>
<img src="graficos\filmes entrada x filmes assistidos aleatoria.png" alt="Alt text" title="Discreto vs Contínuo" width=500rem/>
<img src="graficos\filmes entrada x filmes assistidos geral.png" alt="Alt text" title="Discreto vs Contínuo" width=500rem/>
<img src="graficos\categorias x filmes assistidos gulosa.png" alt="Alt text" title="Discreto vs Contínuo" width=500rem/>
<img src="graficos\categorias x filmes assistidos aleatoria.png" alt="Alt text" title="Discreto vs Contínuo" width=500rem/>
<img src="graficos\categorias x filmes assistidos geral.png" alt="Alt text" title="Discreto vs Contínuo" width=500rem/>
<img src="graficos\filmes assistidos x filmes entrada x categorias gulosa.png" alt="Alt text" title="Discreto vs Contínuo" width=500rem/>
<img src="graficos\filmes assistidos x filmes entrada x categorias aleatoria.png" alt="Alt text" title="Discreto vs Contínuo" width=500rem/>

## Horas assistidas:
Por última à análise do número de filmes, foi avaliado o total de horas assistidas em cada maratona de filmes. Os gráficos abaixo mostram que a dinâmica do número de horas assistidas é semelhante à do número de filmes assistidos. Em ambos os casos, o limite de tempo disponível no dia faz com que os resultados cresçam rapidamente e se estabilizem à medida que esse limite é alcançado. Notavelmente, mesmo com o aumento de categorias e filmes na entrada, as horas assistidas ficam limitadas a 24h para ambas as heurísticas avaliadas:

<img src="graficos\categorias x horas assistidas geral.png" alt="Alt text" title="Discreto vs Contínuo" width=500rem/>
<img src="graficos\categorias x horas assistidas aleatoria.png" alt="Alt text" title="Discreto vs Contínuo" width=500rem/>
<img src="graficos\categorias x horas assistidas gulosa.png" alt="Alt text" title="Discreto vs Contínuo" width=500rem/>
<img src="graficos\filmes entrada x horas assistidas geral.png" alt="Alt text" title="Discreto vs Contínuo" width=500rem/>
<img src="graficos\filmes entrada x horas assistidas aleatoria.png" alt="Alt text" title="Discreto vs Contínuo" width=500rem/>
<img src="graficos\filmes entrada x horas assistidas gulosa.png" alt="Alt text" title="Discreto vs Contínuo" width=500rem/>
<img src="graficos\horas assistidas x filmes entrada x categorias aleatoria.png" alt="Alt text" title="Discreto vs Contínuo" width=500rem/>
<img src="graficos\horas assistidas x filmes entrada x categorias gulosa.png" alt="Alt text" title="Discreto vs Contínuo" width=500rem/>








